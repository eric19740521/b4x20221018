package b4a.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class b4xmainpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.b4xmainpage");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.b4xmainpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.RuntimePermissions _rp = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.cameraexclass _camex = null;
public b4a.example.bctoast _toast = null;
public anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper _server = null;
public anywheresoftware.b4a.objects.SocketWrapper _socket1 = null;
public anywheresoftware.b4a.objects.SocketWrapper.UDPSocket _udp = null;
public anywheresoftware.b4a.randomaccessfile.AsyncStreams _astreams = null;
public anywheresoftware.b4a.randomaccessfile.B4XSerializator _ser = null;
public anywheresoftware.b4a.objects.Timer _pingtimer = null;
public String _remoteaddress = "";
public boolean _isconnect = false;
public boolean _iscamerastart = false;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlpreview = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button1 = null;
public anywheresoftware.b4a.objects.ButtonWrapper _button2 = null;
public anywheresoftware.b4a.objects.ImageViewWrapper _imageview1 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lblconnectstatus = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlmain = null;
public anywheresoftware.b4a.objects.PanelWrapper _panel1 = null;
public b4a.example.main _main = null;
public b4a.example.starter _starter = null;
public b4a.example.b4xpages _b4xpages = null;
public b4a.example.b4xcollections _b4xcollections = null;
public b4a.example.httputils2service _httputils2service = null;
public String  _activityresume() throws Exception{
 //BA.debugLineNum = 103;BA.debugLine="Public Sub ActivityResume";
 //BA.debugLineNum = 104;BA.debugLine="Log(\"B4XMainPage ActivityResume==>\")";
__c.LogImpl("7851969","B4XMainPage ActivityResume==>",0);
 //BA.debugLineNum = 106;BA.debugLine="Try";
try { //BA.debugLineNum = 107;BA.debugLine="If IsCameraStart = False Then";
if (_iscamerastart==__c.False) { 
 //BA.debugLineNum = 108;BA.debugLine="CameraStart";
_camerastart();
 //BA.debugLineNum = 110;BA.debugLine="Log(\"使用APP,系統將起動相機預覽功能...\")";
__c.LogImpl("7851975","使用APP,系統將起動相機預覽功能...",0);
 };
 //BA.debugLineNum = 112;BA.debugLine="UpdateUIStatus		'更新畫面上的UI";
_updateuistatus();
 } 
       catch (Exception e9) {
			ba.setLastException(e9); //BA.debugLineNum = 114;BA.debugLine="Log(LastException)";
__c.LogImpl("7851979",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 118;BA.debugLine="End Sub";
return "";
}
public String  _astreams_error() throws Exception{
 //BA.debugLineNum = 196;BA.debugLine="Private Sub astreams_Error()";
 //BA.debugLineNum = 197;BA.debugLine="Log(\"astreams_Error==>\")";
__c.LogImpl("71114113","astreams_Error==>",0);
 //BA.debugLineNum = 199;BA.debugLine="Log(\"Error: \" & LastException)";
__c.LogImpl("71114115","Error: "+BA.ObjectToString(__c.LastException(ba)),0);
 //BA.debugLineNum = 201;BA.debugLine="astreams_Teminated";
_astreams_teminated();
 //BA.debugLineNum = 203;BA.debugLine="End Sub";
return "";
}
public String  _astreams_newdata(byte[] _buffer) throws Exception{
 //BA.debugLineNum = 189;BA.debugLine="Sub astreams_NewData (Buffer() As Byte)";
 //BA.debugLineNum = 190;BA.debugLine="Log(\"astreams_NewData==>\")";
__c.LogImpl("71048577","astreams_NewData==>",0);
 //BA.debugLineNum = 194;BA.debugLine="End Sub";
return "";
}
public String  _astreams_teminated() throws Exception{
 //BA.debugLineNum = 204;BA.debugLine="Private Sub astreams_Teminated";
 //BA.debugLineNum = 205;BA.debugLine="Log(\"astreams_Teminated==>\")";
__c.LogImpl("71179649","astreams_Teminated==>",0);
 //BA.debugLineNum = 207;BA.debugLine="astreams.Close";
_astreams.Close();
 //BA.debugLineNum = 208;BA.debugLine="IsConnect=False";
_isconnect = __c.False;
 //BA.debugLineNum = 209;BA.debugLine="UpdateUIStatus		'更新畫面上的UI";
_updateuistatus();
 //BA.debugLineNum = 211;BA.debugLine="udp.Close";
_udp.Close();
 //BA.debugLineNum = 212;BA.debugLine="udp.Initialize(\"udp\",9000,8000)";
_udp.Initialize(ba,"udp",(int) (9000),(int) (8000));
 //BA.debugLineNum = 213;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 50;BA.debugLine="Log(\"B4XMainPage B4XPage_Created==>\")";
__c.LogImpl("7720897","B4XMainPage B4XPage_Created==>",0);
 //BA.debugLineNum = 52;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 53;BA.debugLine="Root.LoadLayout(\"MainPage\")";
_root.LoadLayout("MainPage",ba);
 //BA.debugLineNum = 55;BA.debugLine="toast.Initialize(Root )";
_toast._initialize /*String*/ (ba,_root);
 //BA.debugLineNum = 56;BA.debugLine="toast.DurationMs = 1000			'默認持續時間設置為 3000 毫秒";
_toast._durationms /*int*/  = (int) (1000);
 //BA.debugLineNum = 59;BA.debugLine="UpdateUIStatus";
_updateuistatus();
 //BA.debugLineNum = 65;BA.debugLine="If IsCameraStart = False Then";
if (_iscamerastart==__c.False) { 
 //BA.debugLineNum = 66;BA.debugLine="CameraStart";
_camerastart();
 }else {
 //BA.debugLineNum = 69;BA.debugLine="IsCameraStart = False";
_iscamerastart = __c.False;
 //BA.debugLineNum = 70;BA.debugLine="If camEx.IsInitialized Then";
if (_camex.IsInitialized /*boolean*/ ()) { 
 //BA.debugLineNum = 71;BA.debugLine="camEx.Release";
_camex._release /*String*/ ();
 };
 };
 //BA.debugLineNum = 77;BA.debugLine="If File.Exists(File.DirDefaultExternal,\"remoteip.";
if (__c.File.Exists(__c.File.getDirDefaultExternal(),"remoteip.txt")) { 
 //BA.debugLineNum = 78;BA.debugLine="RemoteAddress = File.ReadString(File.DirDefaultE";
_remoteaddress = __c.File.ReadString(__c.File.getDirDefaultExternal(),"remoteip.txt");
 };
 //BA.debugLineNum = 81;BA.debugLine="ConnectToServer		'連線到遠端TCP服務器";
_connecttoserver();
 //BA.debugLineNum = 84;BA.debugLine="pingTimer.Initialize(\"pingTimer\",5000)";
_pingtimer.Initialize(ba,"pingTimer",(long) (5000));
 //BA.debugLineNum = 85;BA.debugLine="pingTimer.Enabled = True";
_pingtimer.setEnabled(__c.True);
 //BA.debugLineNum = 87;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_disappear() throws Exception{
 //BA.debugLineNum = 90;BA.debugLine="Private Sub B4XPage_Disappear";
 //BA.debugLineNum = 91;BA.debugLine="Log(\"B4XMainPage B4XPage_Disappear==>\")";
__c.LogImpl("7786433","B4XMainPage B4XPage_Disappear==>",0);
 //BA.debugLineNum = 93;BA.debugLine="If camEx.IsInitialized Then";
if (_camex.IsInitialized /*boolean*/ ()) { 
 //BA.debugLineNum = 94;BA.debugLine="camEx.Release";
_camex._release /*String*/ ();
 //BA.debugLineNum = 95;BA.debugLine="IsCameraStart = False";
_iscamerastart = __c.False;
 //BA.debugLineNum = 96;BA.debugLine="udp.Close		'UDP測試有時會莫名無法連...放著看看";
_udp.Close();
 //BA.debugLineNum = 98;BA.debugLine="Log(\"APP將離開,系統關閉相機預覽功能...\")";
__c.LogImpl("7786440","APP將離開,系統關閉相機預覽功能...",0);
 };
 //BA.debugLineNum = 100;BA.debugLine="End Sub";
return "";
}
public String  _button2_click() throws Exception{
 //BA.debugLineNum = 176;BA.debugLine="Private Sub Button2_Click";
 //BA.debugLineNum = 179;BA.debugLine="If IsCameraStart = True Then";
if (_iscamerastart==__c.True) { 
 //BA.debugLineNum = 180;BA.debugLine="camEx.TakePicture";
_camex._takepicture /*String*/ ();
 }else {
 //BA.debugLineNum = 182;BA.debugLine="toast.Show(\"相機尚未開啟\")";
_toast._show /*void*/ ("相機尚未開啟");
 };
 //BA.debugLineNum = 187;BA.debugLine="End Sub";
return "";
}
public String  _camera1_picturetaken(byte[] _data) throws Exception{
b4a.example.cameraexclass._camerasize _csize = null;
anywheresoftware.b4a.objects.streams.File.InputStreamWrapper _in = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _b = null;
b4a.example.main._mymessage _mm = null;
 //BA.debugLineNum = 326;BA.debugLine="Private Sub Camera1_PictureTaken (data() As Byte)";
 //BA.debugLineNum = 327;BA.debugLine="Log(\"Camera1_PictureTaken==>\")";
__c.LogImpl("71507329","Camera1_PictureTaken==>",0);
 //BA.debugLineNum = 329;BA.debugLine="Try";
try { //BA.debugLineNum = 331;BA.debugLine="If camEx.IsInitialized = False Then";
if (_camex.IsInitialized /*boolean*/ ()==__c.False) { 
 //BA.debugLineNum = 332;BA.debugLine="toast.Show(\"請先開啟相機\")";
_toast._show /*void*/ ("請先開啟相機");
 //BA.debugLineNum = 333;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 336;BA.debugLine="Dim csize As CameraSize = camEx.GetPictureSize";
_csize = _camex._getpicturesize /*b4a.example.cameraexclass._camerasize*/ ();
 //BA.debugLineNum = 338;BA.debugLine="Log(\"Width: \"&csize.Width)";
__c.LogImpl("71507340","Width: "+BA.NumberToString(_csize.Width /*int*/ ),0);
 //BA.debugLineNum = 339;BA.debugLine="Log(\"Height: \"&csize.Height)";
__c.LogImpl("71507341","Height: "+BA.NumberToString(_csize.Height /*int*/ ),0);
 //BA.debugLineNum = 341;BA.debugLine="camEx.StopPreview";
_camex._stoppreview /*String*/ ();
 //BA.debugLineNum = 351;BA.debugLine="Dim in As InputStream";
_in = new anywheresoftware.b4a.objects.streams.File.InputStreamWrapper();
 //BA.debugLineNum = 352;BA.debugLine="in.InitializeFromBytesArray(data,0,data.Length)";
_in.InitializeFromBytesArray(_data,(int) (0),_data.length);
 //BA.debugLineNum = 353;BA.debugLine="Dim b As Bitmap";
_b = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
 //BA.debugLineNum = 354;BA.debugLine="b.Initialize2(in)";
_b.Initialize2((java.io.InputStream)(_in.getObject()));
 //BA.debugLineNum = 355;BA.debugLine="in.Close";
_in.Close();
 //BA.debugLineNum = 357;BA.debugLine="b=ResizeBitmap(b , 320, 240)	'調整大小";
_b = _resizebitmap(_b,(int) (320),(int) (240));
 //BA.debugLineNum = 358;BA.debugLine="ImageView1.Bitmap =	b";
_imageview1.setBitmap((android.graphics.Bitmap)(_b.getObject()));
 //BA.debugLineNum = 360;BA.debugLine="SaveImage(b)	'將相機拍照存檔";
_saveimage(_b);
 //BA.debugLineNum = 364;BA.debugLine="If IsConnect Then	'傳送到遠端桌面APP";
if (_isconnect) { 
 //BA.debugLineNum = 365;BA.debugLine="Log(\"TCP傳送檔案...\")";
__c.LogImpl("71507367","TCP傳送檔案...",0);
 //BA.debugLineNum = 372;BA.debugLine="Dim mm As MyMessage";
_mm = new b4a.example.main._mymessage();
 //BA.debugLineNum = 373;BA.debugLine="mm.Initialize";
_mm.Initialize();
 //BA.debugLineNum = 375;BA.debugLine="mm.msg_id = server.GetMyIP";
_mm.msg_id /*String*/  = _server.GetMyIP();
 //BA.debugLineNum = 376;BA.debugLine="mm.msg_command = \"picture\"";
_mm.msg_command /*String*/  = "picture";
 //BA.debugLineNum = 377;BA.debugLine="mm.msg_text = \"寬*高= 320*240\"";
_mm.msg_text /*String*/  = "寬*高= 320*240";
 //BA.debugLineNum = 378;BA.debugLine="mm.msg_image = data";
_mm.msg_image /*byte[]*/  = _data;
 //BA.debugLineNum = 381;BA.debugLine="toast.Show(\"傳送中~~~\")";
_toast._show /*void*/ ("傳送中~~~");
 //BA.debugLineNum = 383;BA.debugLine="astreams.Write(ser.ConvertObjectToBytes(mm))";
_astreams.Write(_ser.ConvertObjectToBytes((Object)(_mm)));
 }else {
 //BA.debugLineNum = 387;BA.debugLine="toast.Show(\"未連線?無法傳送檔案?!\")";
_toast._show /*void*/ ("未連線?無法傳送檔案?!");
 };
 //BA.debugLineNum = 396;BA.debugLine="camEx.StartPreview";
_camex._startpreview /*String*/ ();
 } 
       catch (Exception e34) {
			ba.setLastException(e34); //BA.debugLineNum = 400;BA.debugLine="Log(LastException)";
__c.LogImpl("71507402",BA.ObjectToString(__c.LastException(ba)),0);
 };
 //BA.debugLineNum = 406;BA.debugLine="End Sub";
return "";
}
public String  _camera1_preview(byte[] _data) throws Exception{
 //BA.debugLineNum = 322;BA.debugLine="Private Sub Camera1_Preview (data() As Byte)";
 //BA.debugLineNum = 324;BA.debugLine="End Sub";
return "";
}
public void  _camerastart() throws Exception{
ResumableSub_CameraStart rsub = new ResumableSub_CameraStart(this);
rsub.resume(ba, null);
}
public static class ResumableSub_CameraStart extends BA.ResumableSub {
public ResumableSub_CameraStart(b4a.example.b4xmainpage parent) {
this.parent = parent;
}
b4a.example.b4xmainpage parent;
String _permission = "";
boolean _result = false;
boolean _success = false;
b4a.example.cameraexclass._camerasize[] _cs1 = null;
int _i = 0;
b4a.example.cameraexclass._camerasize[] _cs2 = null;
int step12;
int limit12;
int step17;
int limit17;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 123;BA.debugLine="rp.CheckAndRequest(rp.PERMISSION_CAMERA)";
parent._rp.CheckAndRequest(ba,parent._rp.PERMISSION_CAMERA);
 //BA.debugLineNum = 124;BA.debugLine="Wait For B4XPage_PermissionResult (Permission As";
parent.__c.WaitFor("b4xpage_permissionresult", ba, this, null);
this.state = 23;
return;
case 23:
//C
this.state = 1;
_permission = (String) result[0];
_result = (Boolean) result[1];
;
 //BA.debugLineNum = 125;BA.debugLine="If Result = False Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_result==parent.__c.False) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 126;BA.debugLine="toast.Show(\"No permission!\")";
parent._toast._show /*void*/ ("No permission!");
 //BA.debugLineNum = 127;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 132;BA.debugLine="camEx.Initialize(pnlPreview, False , Me, \"Camera1";
parent._camex._initialize /*String*/ (ba,parent._pnlpreview,parent.__c.False,parent,"Camera1");
 //BA.debugLineNum = 136;BA.debugLine="Wait For Camera1_Ready (Success As Boolean)";
parent.__c.WaitFor("camera1_ready", ba, this, null);
this.state = 24;
return;
case 24:
//C
this.state = 5;
_success = (Boolean) result[0];
;
 //BA.debugLineNum = 137;BA.debugLine="If Success Then";
if (true) break;

case 5:
//if
this.state = 22;
if (_success) { 
this.state = 7;
}else {
this.state = 17;
}if (true) break;

case 7:
//C
this.state = 8;
 //BA.debugLineNum = 142;BA.debugLine="Log(\"------------------------------------------\"";
parent.__c.LogImpl("7917526","------------------------------------------",0);
 //BA.debugLineNum = 143;BA.debugLine="Dim cs1() As CameraSize = camEx.GetSupportedPrev";
_cs1 = parent._camex._getsupportedpreviewsizes /*b4a.example.cameraexclass._camerasize[]*/ ();
 //BA.debugLineNum = 144;BA.debugLine="For i=0 To cs1.Length-1";
if (true) break;

case 8:
//for
this.state = 11;
step12 = 1;
limit12 = (int) (_cs1.length /*int*/ -1);
_i = (int) (0) ;
this.state = 25;
if (true) break;

case 25:
//C
this.state = 11;
if ((step12 > 0 && _i <= limit12) || (step12 < 0 && _i >= limit12)) this.state = 10;
if (true) break;

case 26:
//C
this.state = 25;
_i = ((int)(0 + _i + step12)) ;
if (true) break;

case 10:
//C
this.state = 26;
 //BA.debugLineNum = 145;BA.debugLine="Log($\"預覽尺寸可設定參數${i}(寬*高)= ${cs1(i).Width},${cs1";
parent.__c.LogImpl("7917529",("預覽尺寸可設定參數"+parent.__c.SmartStringFormatter("",(Object)(_i))+"(寬*高)= "+parent.__c.SmartStringFormatter("",(Object)(_cs1[_i].Width /*int*/ ))+","+parent.__c.SmartStringFormatter("",(Object)(_cs1[_i].Height /*int*/ ))+""),0);
 if (true) break;
if (true) break;

case 11:
//C
this.state = 12;
;
 //BA.debugLineNum = 147;BA.debugLine="Log(\"------------------------------------------\"";
parent.__c.LogImpl("7917531","------------------------------------------",0);
 //BA.debugLineNum = 148;BA.debugLine="Dim cs2() As CameraSize = camEx.GetSupportedPict";
_cs2 = parent._camex._getsupportedpicturessizes /*b4a.example.cameraexclass._camerasize[]*/ ();
 //BA.debugLineNum = 149;BA.debugLine="For i=0 To cs2.Length-1";
if (true) break;

case 12:
//for
this.state = 15;
step17 = 1;
limit17 = (int) (_cs2.length /*int*/ -1);
_i = (int) (0) ;
this.state = 27;
if (true) break;

case 27:
//C
this.state = 15;
if ((step17 > 0 && _i <= limit17) || (step17 < 0 && _i >= limit17)) this.state = 14;
if (true) break;

case 28:
//C
this.state = 27;
_i = ((int)(0 + _i + step17)) ;
if (true) break;

case 14:
//C
this.state = 28;
 //BA.debugLineNum = 150;BA.debugLine="Log($\"照片尺寸可設定參數${i}(寬*高)= ${cs2(i).Width},${cs2";
parent.__c.LogImpl("7917534",("照片尺寸可設定參數"+parent.__c.SmartStringFormatter("",(Object)(_i))+"(寬*高)= "+parent.__c.SmartStringFormatter("",(Object)(_cs2[_i].Width /*int*/ ))+","+parent.__c.SmartStringFormatter("",(Object)(_cs2[_i].Height /*int*/ ))+""),0);
 if (true) break;
if (true) break;

case 15:
//C
this.state = 22;
;
 //BA.debugLineNum = 152;BA.debugLine="Log(\"------------------------------------------\"";
parent.__c.LogImpl("7917536","------------------------------------------",0);
 //BA.debugLineNum = 156;BA.debugLine="camEx.SetJpegQuality(90)";
parent._camex._setjpegquality /*String*/ ((int) (90));
 //BA.debugLineNum = 157;BA.debugLine="camEx.SetPictureSize(320,240)	'相機存檔時的尺寸";
parent._camex._setpicturesize /*String*/ ((int) (320),(int) (240));
 //BA.debugLineNum = 158;BA.debugLine="camEx.SetPreviewSize(320,240)	'相機預覽時的尺寸";
parent._camex._setpreviewsize /*String*/ ((int) (320),(int) (240));
 //BA.debugLineNum = 159;BA.debugLine="camEx.SetContinuousAutoFocus";
parent._camex._setcontinuousautofocus /*String*/ ();
 //BA.debugLineNum = 160;BA.debugLine="camEx.CommitParameters			'你需要在 CommitParameters";
parent._camex._commitparameters /*String*/ ();
 //BA.debugLineNum = 161;BA.debugLine="camEx.StartPreview";
parent._camex._startpreview /*String*/ ();
 //BA.debugLineNum = 163;BA.debugLine="IsCameraStart = True";
parent._iscamerastart = parent.__c.True;
 if (true) break;

case 17:
//C
this.state = 18;
 //BA.debugLineNum = 165;BA.debugLine="toast.Show(\"Error opening camera\")";
parent._toast._show /*void*/ ("Error opening camera");
 //BA.debugLineNum = 166;BA.debugLine="If camEx.IsInitialized Then";
if (true) break;

case 18:
//if
this.state = 21;
if (parent._camex.IsInitialized /*boolean*/ ()) { 
this.state = 20;
}if (true) break;

case 20:
//C
this.state = 21;
 //BA.debugLineNum = 167;BA.debugLine="camEx.Release";
parent._camex._release /*String*/ ();
 if (true) break;

case 21:
//C
this.state = 22;
;
 if (true) break;

case 22:
//C
this.state = -1;
;
 //BA.debugLineNum = 173;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _b4xpage_permissionresult(String _permission,boolean _result) throws Exception{
}
public void  _camera1_ready(boolean _success) throws Exception{
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private rp As RuntimePermissions";
_rp = new anywheresoftware.b4a.objects.RuntimePermissions();
 //BA.debugLineNum = 11;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private camEx As CameraExClass";
_camex = new b4a.example.cameraexclass();
 //BA.debugLineNum = 13;BA.debugLine="Private toast As BCToast";
_toast = new b4a.example.bctoast();
 //BA.debugLineNum = 15;BA.debugLine="Private server As ServerSocket";
_server = new anywheresoftware.b4a.objects.SocketWrapper.ServerSocketWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private socket1 As Socket";
_socket1 = new anywheresoftware.b4a.objects.SocketWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private udp As UDPSocket";
_udp = new anywheresoftware.b4a.objects.SocketWrapper.UDPSocket();
 //BA.debugLineNum = 18;BA.debugLine="Private astreams As AsyncStreams";
_astreams = new anywheresoftware.b4a.randomaccessfile.AsyncStreams();
 //BA.debugLineNum = 20;BA.debugLine="Private ser As B4XSerializator";
_ser = new anywheresoftware.b4a.randomaccessfile.B4XSerializator();
 //BA.debugLineNum = 21;BA.debugLine="Private pingTimer As Timer";
_pingtimer = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 24;BA.debugLine="Private RemoteAddress As String = \"\"";
_remoteaddress = "";
 //BA.debugLineNum = 25;BA.debugLine="Private IsConnect As Boolean = False";
_isconnect = __c.False;
 //BA.debugLineNum = 26;BA.debugLine="Private IsCameraStart As Boolean = False";
_iscamerastart = __c.False;
 //BA.debugLineNum = 29;BA.debugLine="Private Root As B4XView";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 30;BA.debugLine="Private pnlPreview As Panel";
_pnlpreview = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private Button1 As Button";
_button1 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private Button2 As Button";
_button2 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 33;BA.debugLine="Private ImageView1 As ImageView";
_imageview1 = new anywheresoftware.b4a.objects.ImageViewWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private lblConnectStatus As Label";
_lblconnectstatus = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 38;BA.debugLine="Private pnlMain As Panel";
_pnlmain = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 40;BA.debugLine="Private Panel1 As Panel";
_panel1 = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 41;BA.debugLine="End Sub";
return "";
}
public void  _connecttoserver() throws Exception{
ResumableSub_ConnectToServer rsub = new ResumableSub_ConnectToServer(this);
rsub.resume(ba, null);
}
public static class ResumableSub_ConnectToServer extends BA.ResumableSub {
public ResumableSub_ConnectToServer(b4a.example.b4xmainpage parent) {
this.parent = parent;
}
b4a.example.b4xmainpage parent;
boolean _successful = false;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 244;BA.debugLine="Log(\"ConnectToServer==>\")";
parent.__c.LogImpl("71310721","ConnectToServer==>",0);
 //BA.debugLineNum = 246;BA.debugLine="If RemoteAddress <> \"\" Then";
if (true) break;

case 1:
//if
this.state = 16;
if ((parent._remoteaddress).equals("") == false) { 
this.state = 3;
}else {
this.state = 15;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 247;BA.debugLine="If IsConnect = False Then";
if (true) break;

case 4:
//if
this.state = 13;
if (parent._isconnect==parent.__c.False) { 
this.state = 6;
}else {
this.state = 12;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 249;BA.debugLine="Log(\"socket1準備連線中~~~\")";
parent.__c.LogImpl("71310726","socket1準備連線中~~~",0);
 //BA.debugLineNum = 250;BA.debugLine="socket1.Initialize(\"socket1\")";
parent._socket1.Initialize("socket1");
 //BA.debugLineNum = 251;BA.debugLine="socket1.Connect(RemoteAddress,9001,0)";
parent._socket1.Connect(ba,parent._remoteaddress,(int) (9001),(int) (0));
 //BA.debugLineNum = 252;BA.debugLine="wait for socket1_Connected(successful As Boolea";
parent.__c.WaitFor("socket1_connected", ba, this, null);
this.state = 17;
return;
case 17:
//C
this.state = 7;
_successful = (Boolean) result[0];
;
 //BA.debugLineNum = 253;BA.debugLine="If successful Then";
if (true) break;

case 7:
//if
this.state = 10;
if (_successful) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 254;BA.debugLine="astreams.Initializeprefix(socket1.InputStream,";
parent._astreams.InitializePrefix(ba,parent._socket1.getInputStream(),parent.__c.True,parent._socket1.getOutputStream(),"astreams");
 //BA.debugLineNum = 255;BA.debugLine="IsConnect = True";
parent._isconnect = parent.__c.True;
 //BA.debugLineNum = 256;BA.debugLine="UpdateUIStatus		'更新畫面上的UI";
parent._updateuistatus();
 //BA.debugLineNum = 258;BA.debugLine="pingTimer.Enabled = True";
parent._pingtimer.setEnabled(parent.__c.True);
 //BA.debugLineNum = 260;BA.debugLine="File.WriteString(File.DirDefaultExternal,\"remo";
parent.__c.File.WriteString(parent.__c.File.getDirDefaultExternal(),"remoteip.txt",parent._remoteaddress);
 //BA.debugLineNum = 262;BA.debugLine="Log(\"TCP已經連線,自動關閉UDP連線\")";
parent.__c.LogImpl("71310739","TCP已經連線,自動關閉UDP連線",0);
 //BA.debugLineNum = 263;BA.debugLine="udp.Close";
parent._udp.Close();
 if (true) break;

case 10:
//C
this.state = 13;
;
 if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 267;BA.debugLine="udp.Initialize(\"udp\",9000,8000)		'可能服務器IP有改變.啟動";
parent._udp.Initialize(ba,"udp",(int) (9000),(int) (8000));
 if (true) break;

case 13:
//C
this.state = 16;
;
 if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 270;BA.debugLine="Log(\"RemoteAddress 空白??\")";
parent.__c.LogImpl("71310747","RemoteAddress 空白??",0);
 if (true) break;

case 16:
//C
this.state = -1;
;
 //BA.debugLineNum = 272;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _socket1_connected(boolean _successful) throws Exception{
}
public byte[]  _imagetobytes(anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _image) throws Exception{
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;
 //BA.debugLineNum = 456;BA.debugLine="Public Sub ImageToBytes(Image As Bitmap) As Byte()";
 //BA.debugLineNum = 457;BA.debugLine="Dim out As OutputStream";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
 //BA.debugLineNum = 458;BA.debugLine="out.InitializeToBytesArray(0)";
_out.InitializeToBytesArray((int) (0));
 //BA.debugLineNum = 459;BA.debugLine="Image.WriteToStream(out, 100, \"JPEG\")";
_image.WriteToStream((java.io.OutputStream)(_out.getObject()),(int) (100),BA.getEnumFromString(android.graphics.Bitmap.CompressFormat.class,"JPEG"));
 //BA.debugLineNum = 460;BA.debugLine="out.Close";
_out.Close();
 //BA.debugLineNum = 461;BA.debugLine="Return out.ToBytesArray";
if (true) return _out.ToBytesArray();
 //BA.debugLineNum = 462;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 43;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 44;BA.debugLine="Log(\"B4XMainPage Initialize==>\")";
__c.LogImpl("7655361","B4XMainPage Initialize==>",0);
 //BA.debugLineNum = 46;BA.debugLine="End Sub";
return "";
}
public void  _pingtimer_tick() throws Exception{
ResumableSub_pingTimer_Tick rsub = new ResumableSub_pingTimer_Tick(this);
rsub.resume(ba, null);
}
public static class ResumableSub_pingTimer_Tick extends BA.ResumableSub {
public ResumableSub_pingTimer_Tick(b4a.example.b4xmainpage parent) {
this.parent = parent;
}
b4a.example.b4xmainpage parent;
b4a.example.main._mymessage _mm = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 276;BA.debugLine="Log(\"pingTimer_Tick==>\")";
parent.__c.LogImpl("71376257","pingTimer_Tick==>",0);
 //BA.debugLineNum = 278;BA.debugLine="DateTime.DateFormat = \"yyMMddHHmmss\"";
parent.__c.DateTime.setDateFormat("yyMMddHHmmss");
 //BA.debugLineNum = 279;BA.debugLine="If IsConnect Then";
if (true) break;

case 1:
//if
this.state = 6;
if (parent._isconnect) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 281;BA.debugLine="Log(\"ping傳送...\"&DateTime.Date(DateTime.Now))";
parent.__c.LogImpl("71376262","ping傳送..."+parent.__c.DateTime.Date(parent.__c.DateTime.getNow()),0);
 //BA.debugLineNum = 283;BA.debugLine="Dim mm As MyMessage";
_mm = new b4a.example.main._mymessage();
 //BA.debugLineNum = 284;BA.debugLine="mm.Initialize";
_mm.Initialize();
 //BA.debugLineNum = 286;BA.debugLine="mm.msg_id = server.GetMyIP";
_mm.msg_id /*String*/  = parent._server.GetMyIP();
 //BA.debugLineNum = 287;BA.debugLine="mm.msg_command = \"ping\"";
_mm.msg_command /*String*/  = "ping";
 //BA.debugLineNum = 288;BA.debugLine="mm.msg_text = \"\"";
_mm.msg_text /*String*/  = "";
 //BA.debugLineNum = 291;BA.debugLine="astreams.Write(ser.ConvertObjectToBytes(mm))";
parent._astreams.Write(parent._ser.ConvertObjectToBytes((Object)(_mm)));
 //BA.debugLineNum = 294;BA.debugLine="udp.Close	'UDP服務關閉";
parent._udp.Close();
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 299;BA.debugLine="Log(\"利用UDP,搜尋網路服務器主機...\"&DateTime.Date(DateTime.";
parent.__c.LogImpl("71376280","利用UDP,搜尋網路服務器主機..."+parent.__c.DateTime.Date(parent.__c.DateTime.getNow()),0);
 //BA.debugLineNum = 300;BA.debugLine="udp.Close";
parent._udp.Close();
 //BA.debugLineNum = 301;BA.debugLine="Sleep(500)";
parent.__c.Sleep(ba,this,(int) (500));
this.state = 7;
return;
case 7:
//C
this.state = 6;
;
 //BA.debugLineNum = 302;BA.debugLine="udp.Initialize(\"udp\",9000,8000)";
parent._udp.Initialize(ba,"udp",(int) (9000),(int) (8000));
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 305;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper  _resizebitmap(anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _original,int _width,int _height) throws Exception{
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _new = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper _c = null;
anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper _destrect = null;
 //BA.debugLineNum = 445;BA.debugLine="Sub ResizeBitmap(original As Bitmap, width As Int,";
 //BA.debugLineNum = 446;BA.debugLine="Dim new As Bitmap";
_new = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
 //BA.debugLineNum = 447;BA.debugLine="new.InitializeMutable(width, height)";
_new.InitializeMutable(_width,_height);
 //BA.debugLineNum = 448;BA.debugLine="Dim c As Canvas";
_c = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 449;BA.debugLine="c.Initialize2(new)";
_c.Initialize2((android.graphics.Bitmap)(_new.getObject()));
 //BA.debugLineNum = 450;BA.debugLine="Dim destRect As Rect";
_destrect = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper();
 //BA.debugLineNum = 451;BA.debugLine="destRect.Initialize(0, 0, width, height)";
_destrect.Initialize((int) (0),(int) (0),_width,_height);
 //BA.debugLineNum = 452;BA.debugLine="c.DrawBitmap(original, Null, destRect)";
_c.DrawBitmap((android.graphics.Bitmap)(_original.getObject()),(android.graphics.Rect)(__c.Null),(android.graphics.Rect)(_destrect.getObject()));
 //BA.debugLineNum = 453;BA.debugLine="Return new";
if (true) return _new;
 //BA.debugLineNum = 454;BA.debugLine="End Sub";
return null;
}
public String  _saveimage(anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _original) throws Exception{
String _filename = "";
anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper _b1 = null;
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;
 //BA.debugLineNum = 412;BA.debugLine="Sub SaveImage(original As Bitmap)";
 //BA.debugLineNum = 414;BA.debugLine="Dim fileName As String";
_filename = "";
 //BA.debugLineNum = 416;BA.debugLine="DateTime.DateFormat = \"yyMMddHHmmss\"";
__c.DateTime.setDateFormat("yyMMddHHmmss");
 //BA.debugLineNum = 417;BA.debugLine="fileName = DateTime.Date(DateTime.Now) & \".jpg\"";
_filename = __c.DateTime.Date(__c.DateTime.getNow())+".jpg";
 //BA.debugLineNum = 419;BA.debugLine="Log(\"File= \"&xui.DefaultFolder&\"/\"&fileName)";
__c.LogImpl("71572871","File= "+_xui.getDefaultFolder()+"/"+_filename,0);
 //BA.debugLineNum = 420;BA.debugLine="Log(\"檔案位置= \"&File.DirDefaultExternal &\"/\"&fileNam";
__c.LogImpl("71572872","檔案位置= "+__c.File.getDirDefaultExternal()+"/"+_filename,0);
 //BA.debugLineNum = 422;BA.debugLine="Dim b1 As Bitmap = original	'ResizeBitmap(origina";
_b1 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper();
_b1 = _original;
 //BA.debugLineNum = 424;BA.debugLine="Dim Out As OutputStream";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
 //BA.debugLineNum = 425;BA.debugLine="Out = File.OpenOutput(File.DirDefaultExternal, fi";
_out = __c.File.OpenOutput(__c.File.getDirDefaultExternal(),_filename,__c.False);
 //BA.debugLineNum = 426;BA.debugLine="b1.WriteToStream(Out, 100, \"PNG\")";
_b1.WriteToStream((java.io.OutputStream)(_out.getObject()),(int) (100),BA.getEnumFromString(android.graphics.Bitmap.CompressFormat.class,"PNG"));
 //BA.debugLineNum = 427;BA.debugLine="Out.Close";
_out.Close();
 //BA.debugLineNum = 443;BA.debugLine="End Sub";
return "";
}
public String  _udp_packetarrived(anywheresoftware.b4a.objects.SocketWrapper.UDPSocket.UDPPacket _packet) throws Exception{
String _msg = "";
 //BA.debugLineNum = 215;BA.debugLine="Private Sub udp_PacketArrived (Packet As UDPPacket";
 //BA.debugLineNum = 216;BA.debugLine="Log(\"udp_PacketArrived==>\")";
__c.LogImpl("71245185","udp_PacketArrived==>",0);
 //BA.debugLineNum = 218;BA.debugLine="Log(\"> NEW PACKET\")";
__c.LogImpl("71245187","> NEW PACKET",0);
 //BA.debugLineNum = 220;BA.debugLine="Log(\"Adress: \"&Packet.HostAddress)";
__c.LogImpl("71245189","Adress: "+_packet.getHostAddress(),0);
 //BA.debugLineNum = 227;BA.debugLine="Dim msg As String";
_msg = "";
 //BA.debugLineNum = 228;BA.debugLine="msg = BytesToString(Packet.Data, Packet.Offset, P";
_msg = __c.BytesToString(_packet.getData(),_packet.getOffset(),_packet.getLength(),"UTF8");
 //BA.debugLineNum = 229;BA.debugLine="Log(\"Message received: \" & msg )";
__c.LogImpl("71245198","Message received: "+_msg,0);
 //BA.debugLineNum = 231;BA.debugLine="If msg = \"password:1234\" Then	'確認設備??";
if ((_msg).equals("password:1234")) { 
 //BA.debugLineNum = 232;BA.debugLine="RemoteAddress = Packet.HostAddress";
_remoteaddress = _packet.getHostAddress();
 }else {
 //BA.debugLineNum = 234;BA.debugLine="Log(\"未符合的設備!!!不可連連線\")";
__c.LogImpl("71245203","未符合的設備!!!不可連連線",0);
 //BA.debugLineNum = 235;BA.debugLine="RemoteAddress = \"\"";
_remoteaddress = "";
 };
 //BA.debugLineNum = 239;BA.debugLine="ConnectToServer		'連線到遠端TCP服務器";
_connecttoserver();
 //BA.debugLineNum = 241;BA.debugLine="End Sub";
return "";
}
public String  _updateuistatus() throws Exception{
 //BA.debugLineNum = 307;BA.debugLine="Sub UpdateUIStatus()";
 //BA.debugLineNum = 309;BA.debugLine="If IsConnect = True Then";
if (_isconnect==__c.True) { 
 //BA.debugLineNum = 310;BA.debugLine="lblConnectStatus.Text = \"已連線\"";
_lblconnectstatus.setText(BA.ObjectToCharSequence("已連線"));
 //BA.debugLineNum = 311;BA.debugLine="lblConnectStatus.Color = xui.Color_Green";
_lblconnectstatus.setColor(_xui.Color_Green);
 //BA.debugLineNum = 312;BA.debugLine="lblConnectStatus.TextColor = xui.Color_Black";
_lblconnectstatus.setTextColor(_xui.Color_Black);
 }else {
 //BA.debugLineNum = 314;BA.debugLine="lblConnectStatus.Text = \"未連線\"";
_lblconnectstatus.setText(BA.ObjectToCharSequence("未連線"));
 //BA.debugLineNum = 315;BA.debugLine="lblConnectStatus.Color = xui.Color_Red";
_lblconnectstatus.setColor(_xui.Color_Red);
 //BA.debugLineNum = 316;BA.debugLine="lblConnectStatus.TextColor = xui.Color_White";
_lblconnectstatus.setTextColor(_xui.Color_White);
 };
 //BA.debugLineNum = 319;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
